namespace DIO.Series
{
    public enum Genero
    {
        Ação = 1,
        Aventura = 2,
        Comédia = 3,
        Documentário = 4,
        Drama = 5,
        Espionagem = 6,
        Faroeste = 7,
        Fantasia = 8,
        Ficção_Científica = 9,
        Musical = 10,
        Romance = 11,
        Suspense = 12,
        Terror = 13
    }
}